import 'core/config/app_environment.dart';
import 'main.dart';

void main() => mainCommon(AppEnvironment.dev);

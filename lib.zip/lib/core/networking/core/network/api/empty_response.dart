class EmptyResponse {
  const EmptyResponse();
}
